#include "goblin.h"
using namespace std;

Goblin::Goblin(int x, int y, int hp, double atk, double def, string name):
PC {x, y, hp, atk, def, name} {
    setSteal(5);
}
