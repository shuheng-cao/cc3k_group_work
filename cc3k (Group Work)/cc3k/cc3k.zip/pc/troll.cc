#include "troll.h"
using namespace std;


Troll::Troll(int x, int y, int hp, double atk, double def, string name):
PC{x, y, hp, atk, def,name} {}
