#ifndef __DLC_CONTROLLER_H__
#define __DLC_CONTROLLER_H__
#include <memory>

class DLCController {
public:
    DLCController() = default;
    void play();
};

#endif
