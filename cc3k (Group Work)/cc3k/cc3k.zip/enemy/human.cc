#include "human.h"


Human::Human(int x, int y, std::string name): Enemy{x, y, 125, 25, 25, name} {}




