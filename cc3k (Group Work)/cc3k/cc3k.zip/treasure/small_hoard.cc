#include "small_hoard.h"

SmallHoard::SmallHoard(int x, int y): Treasure{x, y, 1} {}
