#include "normal_hoard.h"

NormalHoard::NormalHoard(int x, int y): Treasure{x, y, 2} {}
