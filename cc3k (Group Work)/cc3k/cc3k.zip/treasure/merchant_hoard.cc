#include "merchant_hoard.h"

MerchantHoard::MerchantHoard(int x, int y): Treasure{x, y, 4} {}
