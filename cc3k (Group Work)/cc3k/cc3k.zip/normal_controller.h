#ifndef __NORMAL_CONTROLLER_H__
#define __NORMAL_CONTROLLER_H__

#include <memory>

class NormalController {
public:
    NormalController() = default;
    void play();
};

#endif
