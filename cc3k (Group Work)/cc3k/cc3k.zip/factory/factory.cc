#include "factory.h"

Factory::~Factory() {
    
}
