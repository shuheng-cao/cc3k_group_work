#ifndef FACTORY_H
#define FACTORY_H

#include "../subject.h"



class Factory {
    
public:
    virtual ~Factory() = 0;
};

#endif
